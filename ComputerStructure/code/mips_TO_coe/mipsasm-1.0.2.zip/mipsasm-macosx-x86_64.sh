#!/bin/sh
exec java \
     -d64 \
     -XstartOnFirstThread \
     -jar mipsasm-macosx-x86_64.jar
